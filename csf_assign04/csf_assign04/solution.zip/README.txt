CONTRIBUTIONS

TODO: write a brief summary of how each team member contributed to
the project.

REPORT

TODO: add your report according to the instructions in the
"Experiments and analysis" section of the assignment description.

Experiments data: 
real    0m0.545s
user    0m0.369s
sys     0m0.004s

real    0m0.296s
user    0m0.470s
sys     0m0.021s

real    0m0.499s
user    0m0.792s
sys     0m0.050s

real    0m1.573s
user    0m1.548s
sys     0m0.444s

real    0m1.639s
user    0m1.685s
sys     0m0.459s

real    0m0.222s
user    0m0.589s
sys     0m0.087s

real    0m1.001s
user    0m0.981s
sys     0m0.591s

real    0m0.221s
user    0m0.653s
sys     0m0.194s
