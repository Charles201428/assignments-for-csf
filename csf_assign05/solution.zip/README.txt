Charles Weng yweng13
Chengqian Fu cfu19

Charles did part of connection.cpp and did receiver.cpp
Chengqian did part of connection.cpp and did sender.cpp
