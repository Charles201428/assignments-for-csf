Charles Weng yweng13
Chengqian Fu cfu19
Charles implements the following functions: 
uint256_create_from_u64
uint256_create
uint256_get_bits
creat from hex
format as hex
left shift
Chengqian implements everything else except for multiplication.
We did multi together.