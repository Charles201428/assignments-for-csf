This is for MS one
Charles Weng (yweng13)
Chengqian Fu (cfu19)
Charles did the c-function part
Chengqian did the assem part
charles did the asm main
chengqian did the test
charles did the rest asm funcs except for read and write
chengqian did read and and write
