Charles Weng (yweng13)
Chengqian Fu (cfu19)
Charles did cache class construction
Chengqian did main file/error handling
