#include <cstdlib>
#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
#include <iostream>
#include <string>
#include "cache.h"
#include "cache.cpp"

using std::string;
using std::vector;
using std::cin;
using std::cout;
using std::endl;
using std::cerr;

int main() {
    int a = std::stoi('a');
    return 0;
}