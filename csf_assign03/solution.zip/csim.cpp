#include <cstdlib>
#include <stdio.h>
#include <string.h>
#include <map>
#include <iostream>

int main(){
    return 0;
}